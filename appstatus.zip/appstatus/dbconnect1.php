<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
if(!mysql_connect("abhaysv.co.in","abhaysv_robocon","lubakku@123"))
{
	die('oops connection problem ! --> '.mysql_error());
}
if(!mysql_select_db("abhaysv_robocon"))
{
	die('oops database selection problem ! --> '.mysql_error());
}

?>